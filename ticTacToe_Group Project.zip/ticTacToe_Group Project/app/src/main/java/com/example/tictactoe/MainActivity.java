package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;



import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private final List<int[]> CombinationList = new ArrayList<>();

    private int[] BoxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0};

    private int PlayerTurn = 1;

    private int TotalBoxSelected = 1;


    private LinearLayout PlayerOneLayout, PlayerTwoLayout;

    private TextView PlayerOneName, PlayerTwoName;

    private ImageView box1, box2, box3, box4, box5, box6, box7, box8, box9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        PlayerOneName = findViewById(R.id.PlayerOneName);
        PlayerTwoName = findViewById(R.id.PlayerTwoName);

        PlayerOneLayout = findViewById(R.id.PlayerOneLayout);
        PlayerTwoLayout = findViewById(R.id.PlayerTwoLayout);

        box1 = findViewById(R.id.box1);
        box2 = findViewById(R.id.box2);
        box3 = findViewById(R.id.box3);
        box4 = findViewById(R.id.box4);
        box5 = findViewById(R.id.box5);
        box6 = findViewById(R.id.box6);
        box7 = findViewById(R.id.box7);
        box8 = findViewById(R.id.box8);
        box9 = findViewById(R.id.box9);


        CombinationList.add(new int[]{0, 1, 2});
        CombinationList.add(new int[]{3, 4, 5});
        CombinationList.add(new int[]{6, 7, 8});
        CombinationList.add(new int[]{0, 3, 6});
        CombinationList.add(new int[]{1, 4, 7});
        CombinationList.add(new int[]{2, 5, 8});
        CombinationList.add(new int[]{0, 4, 8});
        CombinationList.add(new int[]{2, 4, 6});


        final String getPlayerOneName = getIntent().getStringExtra("Player One");
        final String getPlayerTwoName = getIntent().getStringExtra("Player Two");


        PlayerOneName.setText(getPlayerOneName);
        PlayerTwoName.setText(getPlayerTwoName);


        box1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (isBoxSelected(0)) {

                    start((ImageView)view, 0);
                }

            }
        });

        box2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(1)) {

                    start((ImageView)view, 1);
                }
            }
        });

        box3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(2)) {

                    start((ImageView)view, 2);
                }
            }
        });

        box4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(3)) {

                    start((ImageView)view, 3);
                }
            }
        });

        box5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(4)) {

                    start((ImageView)view, 4);
                }
            }
        });

        box6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(5)) {

                    start((ImageView)view, 5);
                }
            }
        });

        box7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(6)) {

                    start((ImageView)view, 6);
                }
            }
        });

        box8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelected(7)) {

                    start((ImageView)view, 7);
                }
            }
        });

        box9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isBoxSelected(8)) {
                    start((ImageView)view, 8);
                }
            }
        });

    }



    private void start(ImageView imageView, int SelectedPosition) {

        BoxPositions[SelectedPosition] = PlayerTurn;

        if(PlayerTurn == 1) {

            imageView.setImageResource(R.drawable.cross);


            if (winner()) {

                WinnerMessage winnerMessage = new WinnerMessage(MainActivity.this, PlayerOneName.getText().toString() + " has won the match", MainActivity.this);
                winnerMessage.setCancelable(false);
                winnerMessage.show();

            } else if (TotalBoxSelected == 9) {

                WinnerMessage winnerMessage = new WinnerMessage(MainActivity.this, "Draw game", MainActivity.this);
                winnerMessage.setCancelable(false);
                winnerMessage.show();
            } else {
                ChangePlayerTurn(2);

                TotalBoxSelected++;
            }
        }
        else{

            imageView.setImageResource(R.drawable.tick);

            if(winner()){
                WinnerMessage winnerMessage = new WinnerMessage(MainActivity.this, PlayerTwoName.getText().toString() + " has won the match", MainActivity.this);
                winnerMessage.setCancelable(false);
                winnerMessage.show();

            }
            else if(SelectedPosition ==9){
                WinnerMessage winnerMessage = new WinnerMessage(MainActivity.this, "Draw game", MainActivity.this);
                winnerMessage.setCancelable(false);
                winnerMessage.show();

            }
            else{
                ChangePlayerTurn(1);

                TotalBoxSelected++;
            }
        }

    }


    private void ChangePlayerTurn(int CurrentPlayerTurn){

        PlayerTurn = CurrentPlayerTurn;

        if (PlayerTurn ==1) {

            PlayerOneLayout.setBackgroundResource(R.drawable.playerturn_outline);
            PlayerTwoLayout.setBackgroundResource(R.drawable.boxdesign);

        }
        else{

            PlayerTwoLayout.setBackgroundResource(R.drawable.playerturn_outline);
            PlayerOneLayout.setBackgroundResource(R.drawable.boxdesign);
        }


    }


    private boolean winner() {

        boolean response = false;

        for (int i = 0; i < CombinationList.size(); i++) {

            final int[] combination = CombinationList.get(i);


            if (BoxPositions[combination[0]] == PlayerTurn && BoxPositions[combination[1]] == PlayerTurn && BoxPositions[combination[2]] == PlayerTurn) {

                response = true;
            }
        }

        return response;
    }

    private boolean isBoxSelected(int BoxPosition){

        boolean response = false;

        if (BoxPositions[BoxPosition] == 0) {
            response = true;
        }
        return response;
    }

    public void RestartMatch(){
        BoxPositions = new int[]{0,0,0,0,0,0,0,0,0};

        PlayerTurn = 1;

        TotalBoxSelected =1;

        box1.setImageResource(R.drawable.dark_blue_box);
        box2.setImageResource(R.drawable.dark_blue_box);
        box3.setImageResource(R.drawable.dark_blue_box);
        box4.setImageResource(R.drawable.dark_blue_box);
        box5.setImageResource(R.drawable.dark_blue_box);
        box6.setImageResource(R.drawable.dark_blue_box);
        box7.setImageResource(R.drawable.dark_blue_box);
        box8.setImageResource(R.drawable.dark_blue_box);
        box9.setImageResource(R.drawable.dark_blue_box);


    }

}
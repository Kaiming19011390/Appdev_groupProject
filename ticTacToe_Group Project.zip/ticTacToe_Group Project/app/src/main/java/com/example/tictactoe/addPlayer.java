package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tictactoe.R;

public class addPlayer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addplayer);

        final EditText PlayerOne = findViewById(R.id.PlayerOneName);
        final EditText PlayerTwo = findViewById(R.id.PlayerTwoName);
        final Button StartBtn = findViewById(R.id.StartBtn);

        StartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String getPlayerOneName = PlayerOne.getText().toString();
                final String getPlayerTwoName = PlayerTwo.getText().toString();

                if(getPlayerOneName.isEmpty() || getPlayerTwoName.isEmpty()){
                    Toast.makeText(addPlayer.this, "Please enter a name", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intent = new Intent( addPlayer.this, com.example.tictactoe.MainActivity.class);
                    intent.putExtra("Player One", getPlayerOneName);
                    intent.putExtra("Player Two", getPlayerTwoName);
                    startActivity(intent);
                }
            }
        });

    }

}